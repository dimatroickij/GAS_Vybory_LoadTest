WorkWithsectionsAction()
{

	return 0;
}
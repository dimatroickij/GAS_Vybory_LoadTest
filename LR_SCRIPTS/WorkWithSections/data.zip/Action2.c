Action2()
{

	web_add_auto_header("Username", 
		"l.n.durov");

	lr_think_time(8);

	web_url("elector-table_2", 
		"URL=http://172.20.101.48/gas-cik-rbd/settings/elector-table", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.48/elector-list", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		LAST);

	web_url("add-marks-search-criteria_2", 
		"URL=http://172.20.101.48/gas-cik-rbd/electors/add-marks-search-criteria", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.48/elector-list", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);

	web_url("elections_2", 
		"URL=http://172.20.101.48/gas-cik-rbd/electors/elections", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.48/elector-list", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		LAST);

	web_url("basic-options", 
		"URL=http://172.20.101.48/gas-cik-ukd/search/basic-options", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.48/elector-list", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		LAST);

	web_url("custom-settings_2", 
		"URL=http://172.20.101.48/gas-cik-ukd/search/custom-settings", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.48/elector-list", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Username");

	web_add_header("Origin", 
		"http://172.20.101.48");

	web_url("openid-configuration_4", 
		"URL=http://idm-websso.ipa-cik.local:8080/realms/test/.well-known/openid-configuration", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.48/error", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("auth_4", 
		"URL=http://idm-websso.ipa-cik.local:8080/realms/test/protocol/openid-connect/auth?client_id=ruiptest&redirect_uri=http%3A%2F%2F172.20.101.48&response_type=id_token%20token&scope=openid%20email%20profile&nonce=e34f36a85b0bf90f9f860a1831ce4840d1HDqjlbT&state=8458d7aad919a45c6b2d1543c38d24bcd2ZqW78sp", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://172.20.101.48/error", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
SearchUIP()
{

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("172.20.101.52", 
		"URL=http://172.20.101.52/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/runtime-es2015.js", ENDITEM, 
		"Url=/polyfills-es2015.js", ENDITEM, 
		"Url=/styles-es2015.js", ENDITEM, 
		"Url=/vendor-es2015.js", ENDITEM, 
		"Url=/main-es2015.js", ENDITEM, 
		"Url=/assets/fonts/PTSans-Regular.ttf", ENDITEM, 
		"Url=/assets/icons/utility-sprite/svg/symbols.svg", ENDITEM, 
		"Url=/assets/img/s-logo.svg", ENDITEM, 
		"Url=/assets/img/side-menu-title.svg", ENDITEM, 
		"Url=/assets/img/menu/cik-data.svg", ENDITEM, 
		"Url=/assets/img/menu/elector-list.svg", ENDITEM, 
		"Url=/assets/img/menu/sul.svg", ENDITEM, 
		"Url=/assets/img/menu/mobile-uip.svg", ENDITEM, 
		"Url=/assets/img/menu/system-log.svg", ENDITEM, 
		"Url=/assets/img/menu/user-settings.svg", ENDITEM, 
		"Url=/assets/img/menu/case_email.svg", ENDITEM, 
		"Url=/assets/img/menu/upload-file.svg", ENDITEM, 
		"Url=/assets/img/favicon.png", ENDITEM, 
		"Url=/assets/fonts/PTSans-Bold.ttf", ENDITEM, 
		"Url=/PTSans-Italic.ttf", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("get", 
		"URL=https://sputnik-lab.com/api-config/settings/get?AppID=browser-b2c-win-id&BrandCode=SPTK&Channel=b2c-common&brandcode=SPTK&company_id=sputnik-lab-b2c-common&domain=voskhod.local&group_id=b2c-common", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_auto_header("Origin", 
		"http://172.20.101.52");

	web_custom_request("logout", 
		"URL=http://172.20.101.52/gas-cik-rbd/users/auth/logout", 
		"Method=POST", 
		"Resource=0", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=/assets/img/fill-logo.svg", "Referer=http://172.20.101.52/login", ENDITEM, 
		LAST);

	web_custom_request("login", 
		"URL=http://172.20.101.52/gas-cik-rbd/users/auth/login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/login", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"username\":\"admin14\",\"password\":\"1111\"}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("X-Auth-Token", 
		"f392d4a4-8298-48e7-8311-e7f4f96676cc");

	web_url("elector-table", 
		"URL=http://172.20.101.52/gas-cik-rbd/settings/elector-table", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("gender", 
		"URL=http://172.20.101.52/gas-cik-rbd/nsi/gender", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("capacity", 
		"URL=http://172.20.101.52/gas-cik-rbd/nsi/capacity", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("country", 
		"URL=http://172.20.101.52/gas-cik-rbd/nsi/country", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("nsi.change_univers_type", 
		"URL=http://172.20.101.52/gas-cik-rbd/nsi/nsi.change_univers_type", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("elector_doc_type", 
		"URL=http://172.20.101.52/gas-cik-rbd/nsi/elector_doc_type", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("elector-attributes-types", 
		"URL=http://172.20.101.52/gas-cik-rbd/nsi/elector-attributes-types", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_url("nsi.change_univers_type_2", 
		"URL=http://172.20.101.52/gas-cik-rbd/nsi/nsi.change_univers_type", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("nsi.change_basis", 
		"URL=http://172.20.101.52/gas-cik-rbd/nsi/nsi.change_basis", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("add-marks-search-criteria", 
		"URL=http://172.20.101.52/gas-cik-rbd/electors/add-marks-search-criteria", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("elections", 
		"URL=http://172.20.101.52/gas-cik-rbd/electors/elections", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("basic-options", 
		"URL=http://172.20.101.52/gas-cik-ukd/search/basic-options", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("elector_doc_type_2", 
		"URL=http://172.20.101.52/gas-cik-rbd/nsi/elector_doc_type", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_url("custom-settings", 
		"URL=http://172.20.101.52/gas-cik-ukd/search/custom-settings", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_url("gender_2", 
		"URL=http://172.20.101.52/gas-cik-rbd/nsi/gender", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_url("974569", 
		"URL=http://172.20.101.52/gas-cik-rbd/addresses/974569", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Auth-Token");

	web_add_header("X-Chrome-UMA-Log-SHA1", 
		"72D1CFD567D1F02CD90DBAFA37C0404A4FF13A0D");

	web_add_header("X-Chrome-UMA-ReportingInfo", 
		"CAE=");

	lr_think_time(4);

	web_custom_request("desktop", 
		"URL=https://sputnik-lab.com/api-logs/desktop", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml, application/xml", 
		"Referer=", 
		"Snapshot=t21.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/vnd.chrome.uma", 
		"BodyBinary=\t\\x9D\\x01z\\xCC\n\\xE2\\xE1\\x1D\\x10\\x0B\\x1A\\xB7\\x11\\x08\\xD0\\xD2\\xDE\\xFC\\x05\\x12\n4.5.4512.0\\x18\\x90\\xC1\\xEB\\xFB\\x05\"\\x02ru*\\x18\n\nWindows NT\\x12\n10.0.177632\\x8A\\x01\n\\x06x86_64\\x10\\xCE}\\x18\\x80\\x80\\xD4\\xA0\\x01\"\\x00(\\x020\\x80\\x0F8\\xB8\\x08B>\\x08\\x86\\x81\\x02\\x10\\x92\\xB2\\x01\\x1A\\x073.3.0.2\"\n2017/04/072\\x0BGoogle Inc.:\\x12Google SwiftShaderM\\xEB\\x13\\xB9BU\\xF2Y\\xB9Be\\x00\\x00\\x80?j\\x14\n"
		"\\x0CGenuineIntel\\x10\\xE9\\x8D$\\x18\\x04\\x82\\x01\\x02\\x08\\x00\\x8A\\x01\\x02\\x08\\x00:=\n\\x13Chromium PDF Viewer\\x12 mhjfbmdgcfjbbpaeojofohoefgiehjai\\x1A\\x00 \\x00(\\x00:B\n\\x0FShockwave Flash\\x12\\x1Fpepflashplayer32_32_0_0_453.dll\\x1A\n32.0.0.453 \\x00(\\x01:0\n\\x13Chromium PDF Plugin\\x12\\x13internal-pdf-viewer\\x1A\\x00 \\x00(\\x01B\\x00J\n\r.u4\\xC1\\x15\\x88,\\xB7\\xB8J\n\r>\\x9F\\xEE\\x98\\x15>\\x9F\\xEE\\x98J\n\rp\\xDD\\xE0\\x16\\x15\\xDF\\x17J?J\n\r"
		"\\x8D\\x8D\\x88\\xB3\\x15\\x91\\x0F\\xBA\\xAFJ\n\r\\x9D\\xBA\\x18l\\x15\\x02\\xB3\\x98=J\n\rEH\\xDB\\x02\\x158\\xE1\\xE4\\xACJ\n\r\\x82Uxt\\x15\\xDF\\x17J?J\n\rl\\xFF\\x1F$\\x15W\\x1C\\xDANJ\n\r\\x0F\\x8FR\\x1E\\x15\\xA2\\x05S\\x01J\n\r\\xB8\\xEC0\\xB1\\x15\\xB8\\xEC0\\xB1J\n\r\\xF7O,\\xD5\\x15\\xF7O,\\xD5J\n\r8\\xBC\\xED\\xB1\\x15\\xADnO\\xCFJ\n\r\\xDF\\xEA\\xD7\\xCD\\x15\\xC9Q\\xAE\\xF5J\n\r\\xE9,u\\x1C\\x15\\xE9,u\\x1CJ\n\r\\xE5\\xF3;\\xD4\\x15\\xE5\\xF3;\\xD4J\n\r\\xDA\\x87?"
		"\\xBA\\x15V\\xA6\\xBDEJ\n\r\\x90\\x85\\xCB\\xA5\\x15\\xDF\\x17J?J\n\raOll\\x15\\xDF\\x17J?J\n\r\\xB8\\x8A\\xB4v\\x15\\\\x10\\xBD\\xD4J\n\r\\xC8A\\x08\\xC7\\x15\\x07pV\\xA2J\n\r`\\xA0{\\xED\\x15\\xDF\\x17J?J\n\r+\\x1A \\x9E\\x15\\xDF\\x17J?J\n\r\\xDC*!'\\x15\\xDC*!'J\n\r\\xC8v\\x15Y\\x15\\xDF\\x17J?J\n\r\t\\xEBtR\\x15\\xDF\\x17J?J\n\r{l\\xC9D\\x15\\xDF\\x17J?J\n\r\\xBBu\\xF5W\\x15\\xDF\\x17J?J\n\r\\x85(\\x81h\\x15\\x87\\xAC/MJ\n\r\\xE9i/\\xB7\\x15\\xDF\\x17J?J\n\r\\x0C\\x91G\\xF3\\x15\\xDF\\x17J?J"
		"\n\r\\xDC\\xDD\\xBBw\\x15\\xDF\\x17J?J\n\r\\xBD\\xD3s\\x97\\x15\\x10\\xA1~|J\n\r\\xCA\\x1Ds\\x93\\x15\\xDF\\x17J?J\n\r\\xE0\\x04\\xA6\\x8F\\x158\\xE1\\xE4\\xACJ\n\r\\xC5-;\\x8E\\x15\\x90%p\\x93J\n\rw\\x95b\\x1E\\x15\\xDF\\x17J?J\n\r\\xF2\\xFB\\xE1=\\x15\\xDF\\x17J?J\n\r\\xC2\\xDF\\xCBd\\x15\\xDF\\x17J?J\n\r|\\x839Q\\x15\\xDF\\x17J?J\n\r\\xD9v\\x81\\x7F\\x15\\xDF\\x17J?J\n\r{\\xB7\\x9C\\xF7\\x15\\xF4\\xF4G=J\n\rqz!\\xF7\\x15xq\\x04\\xB2J\n\r\\xEB\\x98\\xA8#\\x15t\\xCF\\x93\\xFCJ\n\r"
		"\\x90\\xDA\\x8B\\x86\\x15\\xDF\\x17J?J\n\r\\xA6\\x03\\xA3N\\x15\\xDF\\x17J?J\n\r\\x81\"\\xBE\\x12\\x15\\xE5X\\xB1\\xE3J\n\r\\xA9b%\\xD9\\x15\\xBA\\x0E\\xDD\\xE1J\n\r)b\\xA2\\xF4\\x15\\x7F\\xB3aLJ\n\r\\x8AH\\xFC%\\x15\\x87\\xAC/MJ\n\rtO\"d\\x15J\\xFA\\x87PJ\n\r\\x8C/0V\\x15p.\\x88/J\n\r\\xCF\\xA1si\\x15\\xDF\\x17J?J\n\rOl`r\\x15\\xDF\\x17J?J\n\rB\\xB8\\xEC\\x1A\\x15\\xDF\\x17J?J\n\r\\x1C\\xA9\\xC0\\xCA\\x15\\xDF\\x17J?J\n\r\\xA3\\xD4\\xCE\\x1B\\x15\\xF8C\\x1B\\xD6J\n\rR\\x04n\\xF5\\x15\\xDF\\x17J?"
		"J\n\r\\xA00\\xEA\\xF3\\x15\\xDF\\x17J?J\n\r\\x86\\x00/\\x0B\\x15G>\\x05\\x93J\n\r\\xCE7\\xC3K\\x15C\\x18LPJ\n\r[N/\\x9A\\x15\\xDF\\x17J?J\n\ro\\x91G\\xD7\\x15o\\x91G\\xD7J\n\rv|P\\x17\\x15\\xDF\\x17J?J\n\r\\xAA\\xD8Dh\\x15\\xE0\\x04\\x9AfJ\n\r`\\x87MI\\x15\\xDF\\x17J?J\n\r\\x02\\xA3\\xBA4\\x15\\xADnO\\xCFJ\n\r\\xA2\\xF3\\xFF\\xF5\\x15\\xA2\\xF3\\xFF\\xF5J\n\r\\xB2\\xA7\\x7FX\\x15\\xCE\\x8AmrJ\n\r\\x11\\xF8\\xB8\\xBB\\x15\\xDF\\x17J?J\n\r$\\x86\\xE6\\x94\\x15\\xC4\\x8F?\\x80J\n\r"
		"\\xB8\\x1D\\xD9\\x11\\x15 \\x06:\\xD9J\n\r\\xB2\\x88\\xF0>\\x15\\xDF\\x17J?J\n\r\\xC5\\xC2:I\\x15\\xDF\\x17J?J\n\r\\x01\\xAAJ\\xDA\\x15\\xDF\\x17J?J\n\r1\\x90U\\x0C\\x15\\xF4\\xF4G=J\n\r\\x9E\\xB0X\\xE2\\x15\\xDF\\x17J?P\\x00b\\x04SPTKj\\x0C\\x08\\x00\\x10\\x00\\x18\\x00 \\x008\\x05@\\x05\\x80\\x01\\x90\\xC1\\xEB\\xFB\\x05\\x90\\x01\\x14\\x90\\x01/"
		"\\x90\\x01\\xA6\\x01\\x90\\x01\\x9E\\x03\\x90\\x01\\xA0\\x03\\x90\\x01\\xBA\\x04\\x90\\x01\\xBD\\x05\\x90\\x01\\xFC\\x05\\x90\\x01\\x97\\x06\\x90\\x01\\xD9\\x07\\x98\\x01\\x00\\xBA\\x01\\x07\\x15\\x11')\\xD2(\\x01\\xBA\\x01\\x0C\\x15\\x9E\\x0Che%X\\xDF\\xA2\\x84(\\x00\\xC2\\x01\\x0F\\x08\\x0B\\x12\\x069.18.0\\x1D\\xCEAz<\\xC2\\x01\n\\x08\\x08\\x12\\x017\\x1D\\xC0^Q\\xFD\\xC2\\x01\r\\x08\n"
		"\\x12\\x046274\\x1D\\x13Q\\xDC\\xE2\\xC2\\x01\\x0B\\x08\\x02\\x12\\x0243\\x1D\\xD7\\xD2\\xD1\\xFF\\xC2\\x01\\x10\\x08\\x03\\x12\\x070.0.0.0\\x1D\\x00\\x00\\x00\\x00\\xC2\\x01\r\\x08\t\\x12\\x041256\\x1DB|&{\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\n\\x18\\x02 \\x01(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\n\\x18\\x02 "
		"\\x01(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01!\\x08\\x01\\x10\n\\x18\\x02 \\x01(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x00p\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x06\\x10\n\\x18\\x02 \\x00(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 "
		"\\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x01(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00"
		"(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 "
		"\\x01(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00"
		"(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x01(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 "
		"\\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00P\\x00\\x92\\x01$F321ACBF-8699-4C0D-9720-ED1F8C58E840\\xA2\\x01\\x00", 
		LAST);

	web_add_header("X-Chrome-UMA-Log-SHA1", 
		"698C26101D1B7507EFAAE468E4E9F526CF27AA91");

	web_add_auto_header("X-Chrome-UMA-ReportingInfo", 
		"CAEQyAEYACAB");

	web_custom_request("desktop_2", 
		"URL=https://sputnik-lab.com/api-logs/desktop", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml, application/xml", 
		"Referer=", 
		"Snapshot=t22.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/vnd.chrome.uma", 
		"BodyBinary=\t\\x9D\\x01z\\xCC\n\\xE2\\xE1\\x1D\\x10\\x0C\\x1A\\xAB\\x11\\x08\\xD0\\xD2\\xDE\\xFC\\x05\\x12\n4.5.4512.0\\x18\\x90\\xC1\\xEB\\xFB\\x05\"\\x02ru*\\x18\n\nWindows NT\\x12\n10.0.177632\\x8A\\x01\n\\x06x86_64\\x10\\xCE}\\x18\\x80\\x80\\xD4\\xA0\\x01\"\\x00(\\x020\\x80\\x0F8\\xB8\\x08B>\\x08\\x86\\x81\\x02\\x10\\x92\\xB2\\x01\\x1A\\x073.3.0.2\"\n2017/04/072\\x0BGoogle Inc.:\\x12Google SwiftShaderM\\xEB\\x13\\xB9BU\\xF2Y\\xB9Be\\x00\\x00\\x80?j\\x14\n"
		"\\x0CGenuineIntel\\x10\\xE9\\x8D$\\x18\\x04\\x82\\x01\\x02\\x08\\x00\\x8A\\x01\\x02\\x08\\x00:=\n\\x13Chromium PDF Viewer\\x12 mhjfbmdgcfjbbpaeojofohoefgiehjai\\x1A\\x00 \\x00(\\x00:B\n\\x0FShockwave Flash\\x12\\x1Fpepflashplayer32_32_0_0_453.dll\\x1A\n32.0.0.453 \\x00(\\x01:0\n\\x13Chromium PDF Plugin\\x12\\x13internal-pdf-viewer\\x1A\\x00 \\x00(\\x01B\\x0C\\x10\n \\x010\\x08\\xD0\\x01\\x01\\xD8\\x01\\x04J\n\r.u4\\xC1\\x15\\x88,\\xB7\\xB8J\n\rp\\xDD\\xE0\\x16\\x15\\xDF\\x17J?J\n\r"
		"\\x8D\\x8D\\x88\\xB3\\x15\\x91\\x0F\\xBA\\xAFJ\n\r\\x9D\\xBA\\x18l\\x15\\x02\\xB3\\x98=J\n\r\\x82Uxt\\x15\\xDF\\x17J?J\n\rl\\xFF\\x1F$\\x15W\\x1C\\xDANJ\n\r\\x0F\\x8FR\\x1E\\x15\\xA2\\x05S\\x01J\n\r\\xB8\\xEC0\\xB1\\x15\\xB8\\xEC0\\xB1J\n\r\\xF7O,\\xD5\\x15\\xF7O,\\xD5J\n\r8\\xBC\\xED\\xB1\\x15\\xADnO\\xCFJ\n\r\\xDF\\xEA\\xD7\\xCD\\x15\\xC9Q\\xAE\\xF5J\n\r\\xE9,u\\x1C\\x15\\xE9,u\\x1CJ\n\r\\xE5\\xF3;\\xD4\\x15\\xE5\\xF3;\\xD4J\n\r\\xDA\\x87?\\xBA\\x15V\\xA6\\xBDEJ\n\r"
		"\\x90\\x85\\xCB\\xA5\\x15\\xDF\\x17J?J\n\raOll\\x15\\xDF\\x17J?J\n\r\\xB8\\x8A\\xB4v\\x15\\\\x10\\xBD\\xD4J\n\r\\xC8A\\x08\\xC7\\x15\\x07pV\\xA2J\n\r`\\xA0{\\xED\\x15\\xDF\\x17J?J\n\r\\xAA2\\xB4n\\x15\\xDF\\x17J?J\n\r\\xDC*!'\\x15\\xDC*!'J\n\r\\xC8v\\x15Y\\x15\\xDF\\x17J?J\n\r\t\\xEBtR\\x15\\xDF\\x17J?J\n\r{l\\xC9D\\x15\\xDF\\x17J?J\n\r\\xBBu\\xF5W\\x15\\xDF\\x17J?J\n\r\\x85(\\x81h\\x15\\x87\\xAC/MJ\n\r\\xE9i/\\xB7\\x15\\xDF\\x17J?J\n\r\\x0C\\x91G\\xF3\\x15\\xDF\\x17J?J\n\r"
		"\\xDC\\xDD\\xBBw\\x15\\xDF\\x17J?J\n\r\\xBD\\xD3s\\x97\\x15\\x10\\xA1~|J\n\r\\xCA\\x1Ds\\x93\\x15\\xDF\\x17J?J\n\r\\xE0\\x04\\xA6\\x8F\\x158\\xE1\\xE4\\xACJ\n\r\\xC5-;\\x8E\\x15\\x90%p\\x93J\n\rw\\x95b\\x1E\\x15\\xDF\\x17J?J\n\r\\xF2\\xFB\\xE1=\\x15\\xDF\\x17J?J\n\r\\xC2\\xDF\\xCBd\\x15\\xDF\\x17J?J\n\r|\\x839Q\\x15\\xDF\\x17J?J\n\r\\xD9v\\x81\\x7F\\x15\\xDF\\x17J?J\n\r{\\xB7\\x9C\\xF7\\x15\\xF4\\xF4G=J\n\rqz!\\xF7\\x15xq\\x04\\xB2J\n\r\\xEB\\x98\\xA8#\\x15t\\xCF\\x93\\xFCJ\n\r"
		"\\x90\\xDA\\x8B\\x86\\x15\\xDF\\x17J?J\n\r\\xA6\\x03\\xA3N\\x15\\xDF\\x17J?J\n\r\\x81\"\\xBE\\x12\\x15\\xE5X\\xB1\\xE3J\n\r\\xA9b%\\xD9\\x15\\xBA\\x0E\\xDD\\xE1J\n\r)b\\xA2\\xF4\\x15\\x7F\\xB3aLJ\n\r\\x8AH\\xFC%\\x15\\x87\\xAC/MJ\n\rtO\"d\\x15J\\xFA\\x87PJ\n\r\\x8C/0V\\x15p.\\x88/J\n\r\\xCF\\xA1si\\x15\\xDF\\x17J?J\n\rOl`r\\x15\\xDF\\x17J?J\n\rB\\xB8\\xEC\\x1A\\x15\\xDF\\x17J?J\n\r\\x1C\\xA9\\xC0\\xCA\\x15\\xDF\\x17J?J\n\r\\xA3\\xD4\\xCE\\x1B\\x15\\xF8C\\x1B\\xD6J\n\rR\\x04n\\xF5\\x15\\xDF\\x17J?"
		"J\n\r\\xA00\\xEA\\xF3\\x15\\xDF\\x17J?J\n\r\\x86\\x00/\\x0B\\x15G>\\x05\\x93J\n\r\\xCE7\\xC3K\\x15C\\x18LPJ\n\r[N/\\x9A\\x15\\xDF\\x17J?J\n\ro\\x91G\\xD7\\x15o\\x91G\\xD7J\n\rv|P\\x17\\x15\\xDF\\x17J?J\n\r\\xAA\\xD8Dh\\x15\\xE0\\x04\\x9AfJ\n\r`\\x87MI\\x15\\xDF\\x17J?J\n\r\\x02\\xA3\\xBA4\\x15\\xADnO\\xCFJ\n\r\\xA2\\xF3\\xFF\\xF5\\x15\\xA2\\xF3\\xFF\\xF5J\n\r\\xB2\\xA7\\x7FX\\x15\\xCE\\x8AmrJ\n\r\\x11\\xF8\\xB8\\xBB\\x15\\xDF\\x17J?J\n\r$\\x86\\xE6\\x94\\x15\\xC4\\x8F?\\x80J\n\r"
		"\\xB8\\x1D\\xD9\\x11\\x15 \\x06:\\xD9J\n\r\\xB2\\x88\\xF0>\\x15\\xDF\\x17J?J\n\r\\xC5\\xC2:I\\x15\\xDF\\x17J?J\n\r\\x01\\xAAJ\\xDA\\x15\\xDF\\x17J?J\n\r1\\x90U\\x0C\\x15\\xF4\\xF4G=J\n\r\\x9E\\xB0X\\xE2\\x15\\xDF\\x17J?P\\x00b\\x04SPTKj\\x0C\\x08\\x00\\x10\\x00\\x18\\x00 \\x008\\x05@\\x06\\x80\\x01\\x90\\xC1\\xEB\\xFB\\x05\\x90\\x01\\x14\\x90\\x01/"
		"\\x90\\x01\\xA6\\x01\\x90\\x01\\x9E\\x03\\x90\\x01\\xA0\\x03\\x90\\x01\\xBA\\x04\\x90\\x01\\xBD\\x05\\x90\\x01\\xFC\\x05\\x90\\x01\\x97\\x06\\x90\\x01\\xD9\\x07\\x98\\x01\\x00\\xBA\\x01\\x07\\x15\\x11')\\xD2(\\x01\\xBA\\x01\\x0C\\x15\\x9E\\x0Che%X\\xDF\\xA2\\x84(\\x00\\xC2\\x01\\x0F\\x08\\x0B\\x12\\x069.18.0\\x1D\\xCEAz<\\xC2\\x01\n\\x08\\x08\\x12\\x017\\x1D\\xC0^Q\\xFD\\xC2\\x01\r\\x08\n"
		"\\x12\\x046274\\x1D\\x13Q\\xDC\\xE2\\xC2\\x01\\x0B\\x08\\x02\\x12\\x0243\\x1D\\xD7\\xD2\\xD1\\xFF\\xC2\\x01\\x10\\x08\\x03\\x12\\x070.0.0.0\\x1D\\x00\\x00\\x00\\x00\\xC2\\x01\r\\x08\t\\x12\\x041256\\x1DB|&{\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\n\\x18\\x02 \\x01(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\n\\x18\\x02 "
		"\\x01(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01!\\x08\\x01\\x10\n\\x18\\x02 \\x01(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x00p\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x06\\x10\n\\x18\\x02 \\x00(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 "
		"\\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x01(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00"
		"(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 "
		"\\x01(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00"
		"(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x01(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 "
		"\\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00P\\x00\\x92\\x01$F321ACBF-8699-4C0D-9720-ED1F8C58E840\\x9A\\x01:\n\tUser.Info\\x12\\x16\n\\x08UserName\\x12\nd.troickiy\\x12\\x15\n\nDomainName\\x12\\x07VOSKHOD\\x9A\\x01\\x90\\x01\n\\x17browser.page_transition\\x12\\x0C\n\\x08url_from\\x12\\x00\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.52/"
		"\\x12\\x1A\n\ttimestamp\\x12\r1606915737739\\x121\n\\x0Ftransition_type\\x12\\x1EPAGE_TRANSITION_AUTO_TOPLEVEL,\\x9A\\x01\\x95\\x01\n\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.52/\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.52/\\x12\\x1A\n\ttimestamp\\x12\r1606915741178\\x12(\n\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\x9A\\x01\\xA1\\x01\n\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.52/\\x12$\n\\x06url_to\\x12\\x1A172.20.101.52/"
		"elector-list\\x12\\x1A\n\ttimestamp\\x12\r1606915753559\\x12(\n\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\x9A\\x01\\xA6\\x01\n\\x17browser.page_transition\\x12&\n\\x08url_from\\x12\\x1A172.20.101.52/elector-list\\x12\\x1D\n\\x06url_to\\x12\\x13172.20.101.52/login\\x12\\x1A\n\ttimestamp\\x12\r1606915754064\\x12(\n\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\x9A\\x01H\n\\x12WebtextLogger.Info\\x12!\n\\x03url\\x12\\x1Ahttp://172.20.101.52/login\\x12\\x0F\n"
		"\\x04text\\x12\\x07admin14\\x9A\\x01\\x9A\\x01\n\\x17browser.page_transition\\x12\\x1F\n\\x08url_from\\x12\\x13172.20.101.52/login\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.52/\\x12\\x1A\n\ttimestamp\\x12\r1606915757561\\x12(\n\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\x9A\\x01\\xA1\\x01\n\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.52/\\x12$\n\\x06url_to\\x12\\x1A172.20.101.52/elector-list\\x12\\x1A\n\ttimestamp\\x12\r1606915758621\\x12(\n"
		"\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\x9A\\x01d\n\\x08branding\\x12#\n\tCompanyID\\x12\\x16sputnik-lab-b2c-common\\x12\\x17\n\tSegmentID\\x12\nb2c-common\\x12\\x1A\n\ttimestamp\\x12\r1606915765014\\xA2\\x01\\x00", 
		LAST);

	web_add_header("X-Chrome-UMA-Log-SHA1", 
		"8A240FF2CEFF85A64A223475C67C9646AE3025F6");

	web_custom_request("desktop_3", 
		"URL=https://sputnik-lab.com/api-logs/desktop", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml, application/xml", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/vnd.chrome.uma", 
		"BodyBinary=\t\\x9D\\x01z\\xCC\n\\xE2\\xE1\\x1D\\x10\\x0B\\x1A\\xC3\\x11\\x08\\xD0\\xD2\\xDE\\xFC\\x05\\x12\n4.5.4512.0\\x18\\x90\\xC1\\xEB\\xFB\\x05\"\\x02ru*\\x18\n\nWindows NT\\x12\n10.0.177632\\x8A\\x01\n\\x06x86_64\\x10\\xCE}\\x18\\x80\\x80\\xD4\\xA0\\x01\"\\x00(\\x020\\x80\\x0F8\\xB8\\x08B>\\x08\\x86\\x81\\x02\\x10\\x92\\xB2\\x01\\x1A\\x073.3.0.2\"\n2017/04/072\\x0BGoogle Inc.:\\x12Google SwiftShaderM\\xEB\\x13\\xB9BU\\xF2Y\\xB9Be\\x00\\x00\\x80?j\\x14\n"
		"\\x0CGenuineIntel\\x10\\xE9\\x8D$\\x18\\x04\\x82\\x01\\x02\\x08\\x00\\x8A\\x01\\x02\\x08\\x00:=\n\\x13Chromium PDF Viewer\\x12 mhjfbmdgcfjbbpaeojofohoefgiehjai\\x1A\\x00 \\x00(\\x00:B\n\\x0FShockwave Flash\\x12\\x1Fpepflashplayer32_32_0_0_453.dll\\x1A\n32.0.0.453 \\x00(\\x01:0\n\\x13Chromium PDF Plugin\\x12\\x13internal-pdf-viewer\\x1A\\x00 \\x00(\\x01B\\x0C\\x08\\xDEh\\x10\t\\xB8\\x01\\xA3w\\xD0\\x01\\x01J\n\r.u4\\xC1\\x15\\x88,\\xB7\\xB8J\n\r>\\x9F\\xEE\\x98\\x15>\\x9F\\xEE\\x98J\n\r"
		"p\\xDD\\xE0\\x16\\x15\\xDF\\x17J?J\n\r\\x8D\\x8D\\x88\\xB3\\x15\\x91\\x0F\\xBA\\xAFJ\n\r\\x9D\\xBA\\x18l\\x15\\x02\\xB3\\x98=J\n\rEH\\xDB\\x02\\x158\\xE1\\xE4\\xACJ\n\r\\x82Uxt\\x15\\xDF\\x17J?J\n\rl\\xFF\\x1F$\\x15W\\x1C\\xDANJ\n\r\\x0F\\x8FR\\x1E\\x15\\xA2\\x05S\\x01J\n\r\\xB8\\xEC0\\xB1\\x15\\xB8\\xEC0\\xB1J\n\r\\xF7O,\\xD5\\x15\\xF7O,\\xD5J\n\r8\\xBC\\xED\\xB1\\x15\\xADnO\\xCFJ\n\r\\xDF\\xEA\\xD7\\xCD\\x15\\xC9Q\\xAE\\xF5J\n\r\\xE9,u\\x1C\\x15\\xE9,u\\x1CJ\n\r\\xE5\\xF3;\\xD4\\x15\\xE5\\xF3;"
		"\\xD4J\n\r\\xDA\\x87?\\xBA\\x15V\\xA6\\xBDEJ\n\r\\x90\\x85\\xCB\\xA5\\x15\\xDF\\x17J?J\n\raOll\\x15\\xDF\\x17J?J\n\r\\xB8\\x8A\\xB4v\\x15\\\\x10\\xBD\\xD4J\n\r\\xC8A\\x08\\xC7\\x15\\x07pV\\xA2J\n\r`\\xA0{\\xED\\x15\\xDF\\x17J?J\n\r+\\x1A \\x9E\\x15\\xDF\\x17J?J\n\r\\xDC*!'\\x15\\xDC*!'J\n\r\\xC8v\\x15Y\\x15\\xDF\\x17J?J\n\r\t\\xEBtR\\x15\\xDF\\x17J?J\n\r{l\\xC9D\\x15\\xDF\\x17J?J\n\r\\xBBu\\xF5W\\x15\\xDF\\x17J?J\n\r\\x85(\\x81h\\x15\\x87\\xAC/MJ\n\r\\xE9i/\\xB7\\x15\\xDF\\x17J?J\n\r"
		"\\x0C\\x91G\\xF3\\x15\\xDF\\x17J?J\n\r\\xDC\\xDD\\xBBw\\x15\\xDF\\x17J?J\n\r\\xBD\\xD3s\\x97\\x15\\x10\\xA1~|J\n\r\\xCA\\x1Ds\\x93\\x15\\xDF\\x17J?J\n\r\\xE0\\x04\\xA6\\x8F\\x158\\xE1\\xE4\\xACJ\n\r\\xC5-;\\x8E\\x15\\x90%p\\x93J\n\rw\\x95b\\x1E\\x15\\xDF\\x17J?J\n\r\\xF2\\xFB\\xE1=\\x15\\xDF\\x17J?J\n\r\\xC2\\xDF\\xCBd\\x15\\xDF\\x17J?J\n\r|\\x839Q\\x15\\xDF\\x17J?J\n\r\\xD9v\\x81\\x7F\\x15\\xDF\\x17J?J\n\r{\\xB7\\x9C\\xF7\\x15\\xF4\\xF4G=J\n\rqz!\\xF7\\x15xq\\x04\\xB2J\n\r"
		"\\xEB\\x98\\xA8#\\x15t\\xCF\\x93\\xFCJ\n\r\\x90\\xDA\\x8B\\x86\\x15\\xDF\\x17J?J\n\r\\xA6\\x03\\xA3N\\x15\\xDF\\x17J?J\n\r\\x81\"\\xBE\\x12\\x15\\xE5X\\xB1\\xE3J\n\r\\xA9b%\\xD9\\x15\\xBA\\x0E\\xDD\\xE1J\n\r)b\\xA2\\xF4\\x15\\x7F\\xB3aLJ\n\r\\x8AH\\xFC%\\x15\\x87\\xAC/MJ\n\rtO\"d\\x15J\\xFA\\x87PJ\n\r\\x8C/0V\\x15p.\\x88/J\n\r\\xCF\\xA1si\\x15\\xDF\\x17J?J\n\rOl`r\\x15\\xDF\\x17J?J\n\rB\\xB8\\xEC\\x1A\\x15\\xDF\\x17J?J\n\r\\x1C\\xA9\\xC0\\xCA\\x15\\xDF\\x17J?J\n\r"
		"\\xA3\\xD4\\xCE\\x1B\\x15\\xF8C\\x1B\\xD6J\n\rR\\x04n\\xF5\\x15\\xDF\\x17J?J\n\r\\xA00\\xEA\\xF3\\x15\\xDF\\x17J?J\n\r\\x86\\x00/\\x0B\\x15G>\\x05\\x93J\n\r\\xCE7\\xC3K\\x15C\\x18LPJ\n\r[N/\\x9A\\x15\\xDF\\x17J?J\n\ro\\x91G\\xD7\\x15o\\x91G\\xD7J\n\rv|P\\x17\\x15\\xDF\\x17J?J\n\r\\xAA\\xD8Dh\\x15\\xE0\\x04\\x9AfJ\n\r`\\x87MI\\x15\\xDF\\x17J?J\n\r\\x02\\xA3\\xBA4\\x15\\xADnO\\xCFJ\n\r\\xA2\\xF3\\xFF\\xF5\\x15\\xA2\\xF3\\xFF\\xF5J\n\r\\xB2\\xA7\\x7FX\\x15\\xCE\\x8AmrJ\n\r"
		"\\x11\\xF8\\xB8\\xBB\\x15\\xDF\\x17J?J\n\r$\\x86\\xE6\\x94\\x15\\xC4\\x8F?\\x80J\n\r\\xB8\\x1D\\xD9\\x11\\x15 \\x06:\\xD9J\n\r\\xB2\\x88\\xF0>\\x15\\xDF\\x17J?J\n\r\\xC5\\xC2:I\\x15\\xDF\\x17J?J\n\r\\x01\\xAAJ\\xDA\\x15\\xDF\\x17J?J\n\r1\\x90U\\x0C\\x15\\xF4\\xF4G=J\n\r\\x9E\\xB0X\\xE2\\x15\\xDF\\x17J?P\\x00b\\x04SPTKj\\x0C\\x08\\x00\\x10\\x00\\x18\\x00 \\x008\\x05@\\x05\\x80\\x01\\x90\\xC1\\xEB\\xFB\\x05\\x90\\x01\\x14\\x90\\x01/"
		"\\x90\\x01\\xA6\\x01\\x90\\x01\\x9E\\x03\\x90\\x01\\xA0\\x03\\x90\\x01\\xBA\\x04\\x90\\x01\\xBD\\x05\\x90\\x01\\xFC\\x05\\x90\\x01\\x97\\x06\\x90\\x01\\xD9\\x07\\x98\\x01\\x00\\xBA\\x01\\x07\\x15\\x11')\\xD2(\\x01\\xBA\\x01\\x0C\\x15\\x9E\\x0Che%X\\xDF\\xA2\\x84(\\x00\\xC2\\x01\\x0F\\x08\\x0B\\x12\\x069.18.0\\x1D\\xCEAz<\\xC2\\x01\n\\x08\\x08\\x12\\x017\\x1D\\xC0^Q\\xFD\\xC2\\x01\r\\x08\n"
		"\\x12\\x046274\\x1D\\x13Q\\xDC\\xE2\\xC2\\x01\\x0B\\x08\\x02\\x12\\x0243\\x1D\\xD7\\xD2\\xD1\\xFF\\xC2\\x01\\x10\\x08\\x03\\x12\\x070.0.0.0\\x1D\\x00\\x00\\x00\\x00\\xC2\\x01\r\\x08\t\\x12\\x041256\\x1DB|&{\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\n\\x18\\x02 \\x01(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\n\\x18\\x02 "
		"\\x01(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01!\\x08\\x01\\x10\n\\x18\\x02 \\x01(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x00p\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x06\\x10\n\\x18\\x02 \\x00(\\x000\\x008\\x01@\\x00H\\x00P\\x00X\\x01`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 "
		"\\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x01(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00"
		"(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 "
		"\\x01(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 \\x00"
		"(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x02x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x01(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x01x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x04\\x10\\x05\\x18\\x01 "
		"\\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\xCA\\x01\\x1F\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00H\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\"\\x10\t\\x15\\x93[i\\x01#r\\xAC\\x10\\xB1\\xA7\\x89\\x9D\\xE2.\"\\x10\t\\xDF\\xBE\\x11\\x7F\\xEB{/\\xB5\\x10\\xB5\\xA7\\x89\\x9D\\xE2.\"\\x10\t\\xA8HH\\xA3\\xA8\\x88j\\xE8\\x10\\xCF\\xA7\\x89\\x9D\\xE2.\"\\x10\t\\x14m3\\xADs\\xA5\\xB0\\x08\\x10\\xD8\\xAC\\x89\\x9D\\xE2.\"\\x10\t"
		"\\x14m3\\xADs\\xA5\\xB0\\x08\\x10\\xB9\\xB4\\x89\\x9D\\xE2.\"\\x10\t\\x15\\x93[i\\x01#r\\xAC\\x10\\xDF\\xBC\\x89\\x9D\\xE2.\"\\x10\t\\x14m3\\xADs\\xA5\\xB0\\x08\\x10\\xE9\\xBE\\x89\\x9D\\xE2.\"\\x10\tR@\\xF5^\\xA8qU_\\x10\\xF7\\xBE\\x89\\x9D\\xE2.\"\\x10\tR@\\xF5^\\xA8qU_\\x10\\xCE\\xBF\\x89\\x9D\\xE2.\"\\x10\t\\x15\\x93[i\\x01#r\\xAC\\x10\\xD4\\xD0\\x89\\x9D\\xE2.\"\\x10\t\\x14m3\\xADs\\xA5\\xB0\\x08\\x10\\xAF\\xDD\\x89\\x9D\\xE2.\"\\x10\t"
		"\\x14m3\\xADs\\xA5\\xB0\\x08\\x10\\xA5\\xDF\\x89\\x9D\\xE2.\"\\x10\t\\xE7\rp\\x0Cu\\x1E6\\x8C\\x10\\xB0\\xDF\\x89\\x9D\\xE2.\"\\x10\t4\\xFEs\\x8C\\xC0\\x1B\\xF4\\x9F\\x10\\xB0\\xDF\\x89\\x9D\\xE2.\"\\x10\t\\x15\\x93[i\\x01#r\\xAC\\x10\\xA0\\xE0\\x89\\x9D\\xE2.\"\\x10\t\\x14m3\\xADs\\xA5\\xB0\\x08\\x10\\xA1\\xE0\\x89\\x9D\\xE2.\"\\x10\t\\x15\\x93[i\\x01#r\\xAC\\x10\\xA8\\xE0\\x89\\x9D\\xE2.\"\\x10\t\\x15\\x93[i\\x01#r\\xAC\\x10\\xC7\\xE1\\x89\\x9D\\xE2.\"\\x10\t"
		"\\x14m3\\xADs\\xA5\\xB0\\x08\\x10\\xC7\\xE1\\x89\\x9D\\xE2.\"\\x10\t\\x15\\x93[i\\x01#r\\xAC\\x10\\x85\\xF6\\x89\\x9D\\xE2.\"\\x10\t\\x14m3\\xADs\\xA5\\xB0\\x08\\x10\\x87\\xF6\\x89\\x9D\\xE2.\"\\x10\t\\x15\\x93[i\\x01#r\\xAC\\x10\\xFF\\xF9\\x89\\x9D\\xE2.\"\\x10\t\\x14m3\\xADs\\xA5\\xB0\\x08\\x10\\x80\\xFA\\x89\\x9D\\xE2.\"\\x10\t\\xA8HH\\xA3\\xA8\\x88j\\xE8\\x10\\xCE\\x8F\\x8A\\x9D\\xE2.\"\\x10\t\\xA8HH\\xA3\\xA8\\x88j\\xE8\\x10\\x92\\x92\\x8A\\x9D\\xE2.\"\\x10\t"
		"\\xA8HH\\xA3\\xA8\\x88j\\xE8\\x10\\xF4\\x9A\\x8A\\x9D\\xE2.\"\\x10\tk\\xF6\\x91\\x07\\x11d\\xC1\\x99\\x10\\xD1\\x9B\\x8A\\x9D\\xE2.\"\\x10\t\\xDF\\xBE\\x11\\x7F\\xEB{/\\xB5\\x10\\xD8\\x9B\\x8A\\x9D\\xE2.\"\\x10\t\\xA8HH\\xA3\\xA8\\x88j\\xE8\\x10\\xC9\\xA3\\x8A\\x9D\\xE2.\"\\x10\t\\xA8HH\\xA3\\xA8\\x88j\\xE8\\x10\\xE4\\x84\\x8E\\x9D\\xE2.\"\\x10\tk\\xF6\\x91\\x07\\x11d\\xC1\\x99\\x10\\xA1\\x96\\x8E\\x9D\\xE2.\"\\x10\t\\x15\\x93[i\\x01#r\\xAC\\x10\\xBD\\x96\\x8E\\x9D\\xE2.\"\\x10\t"
		"\\xDF\\xBE\\x11\\x7F\\xEB{/\\xB5\\x10\\xC0\\x96\\x8E\\x9D\\xE2.\"\\x10\t\\xE1:\\xEB\\x1D%+\\xDDZ\\x10\\xC8\\x96\\x8E\\x9D\\xE2.\"\\x10\t\\x8F\\xDA\\x03 \\x1Ca{Z\\x10\\xC8\\x96\\x8E\\x9D\\xE2.\"\\x10\t\\x14m3\\xADs\\xA5\\xB0\\x08\\x10\\xD1\\x96\\x8E\\x9D\\xE2.P\\x00\\x92\\x01$F321ACBF-8699-4C0D-9720-ED1F8C58E840\\x9A\\x01\\xF3\\x12\n\\x17browser.page_transition\\x12%\n\\x08url_from\\x12\\x19172.20.101.48/zags-import\\x12\\xCA\\x11\n\\x06url_to\\x12\\xBF\\x11172.20.101.48/#state="
		"b02ca27912e4a915910bb9ed1f057aecbdncVo9VW&session_state=75f8d79c-e114-4689-93a5-e78e5dd329cb&id_token="
		"eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJFUng4czVncHN2QUdmbks0b2hpWmxnM3hjVnRXU2JTLURUNmRZcFhYLWxRIn0.eyJqdGkiOiJhYTRhYmQ2NS0zZWYxLTQxYzAtYTcwZi0yNDgxZmJkNTVlMjEiLCJleHAiOjE2MDY5MDEzODQsIm5iZiI6MCwiaWF0IjoxNjA2OTAwNDg0LCJpc3MiOiJodHRwOi8vaWRtLXdlYnNzby5pcGEtY2lrLmxvY2FsOjgwODAvcmVhbG1zL3Rlc3QiLCJhdWQiOiJydWlwdGVzdCIsInN1YiI6IjY0ZjI3N2FkLTA5MjAtNDg2Yi05ZTM5LTU4ZDc5MTFiZTk1ZCIsInR5cCI6IklEIiwiYXpwIjoicnVpcHRlc3QiLCJub25jZSI6IjQ5ODBmNDBkZmYwN2RmZDkwOTFhNThmYzRlZWJjNzM0YTFCME40TnNpIiwiYXV0aF"
		"90aW1lIjoxNjA2OTAwNDY1LCJzZXNzaW9uX3N0YXRlIjoiNzVmOGQ3OWMtZTExNC00Njg5LTkzYTUtZTc4ZTVkZDMyOWNiIiwiYXRfaGFzaCI6Im1yekxiTHkwbGJJTjZkcEQxVUlzb0EiLCJhY3IiOiIwIiwic19oYXNoIjoiQ2UzcEE0U2owRFdUNHladThJS2h2dyIsInVzZXJuYW1lIjoibC5uLmR1cm92In0.TF3Q2IY9xPSHOMwufeYsWmNWCTzKq1wFnndK9TCfiEbxeUTiGwCX5HbdntFrUv7_98Npa97MqJbb-ypSvhDNLOwyed_HIxAH128Q6wxF7LPvW43CxG8wKPhky1LVgwrjRyxVk_dgOlo6FcDPHAh0ymKlV5favpGGm-2aCZ8zAc4s0_coO40vC9WIMRB1D6IfOYgrXpyrVS1OQEN50CFEvAUZsHtPwsg2vQamZrvHsvRV-WbX9FmLfCwZWciACRjxEqsO5PhnHE5v"
		"IXgPgkD7UifR0vDmMk7nBdD9hlYb7y3DLeHovFs6Ct5Cl_qpeUZYvieZCjhWSbftkaCLFUCmFA&access_token="
		"eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJFUng4czVncHN2QUdmbks0b2hpWmxnM3hjVnRXU2JTLURUNmRZcFhYLWxRIn0.eyJqdGkiOiI5MzY4MGRkYi04YmYxLTQ3MTMtOTUwYy00MTRmOWU4YTlhYzAiLCJleHAiOjE2MDY5MDEzODQsIm5iZiI6MCwiaWF0IjoxNjA2OTAwNDg0LCJpc3MiOiJodHRwOi8vaWRtLXdlYnNzby5pcGEtY2lrLmxvY2FsOjgwODAvcmVhbG1zL3Rlc3QiLCJzdWIiOiI2NGYyNzdhZC0wOTIwLTQ4NmItOWUzOS01OGQ3OTExYmU5NWQiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJydWlwdGVzdCIsIm5vbmNlIjoiNDk4MGY0MGRmZjA3ZGZkOTA5MWE1OGZjNGVlYmM3MzRhMUIwTjROc2kiLCJhdXRoX3RpbWUiOjE2MDY5MD"
		"A0NjUsInNlc3Npb25fc3RhdGUiOiI3NWY4ZDc5Yy1lMTE0LTQ2ODktOTNhNS1lNzhlNWRkMzI5Y2IiLCJhY3IiOiIwIiwic2NvcGUiOiJvcGVuaWQiLCJ1c2VybmFtZSI6Imwubi5kdXJvdiJ9.VmiGZow0aqdi0yiyLCkvgNiOx2dmXil7bor9skX6jOVkgPlcpPfaNcT7Z-TrgQHjSXm-o56k0BPHupgd5AV4GNjDHtE8oCNqlunShhrB8enr4A1hjNvgGYEb-uRtUE4IOG9dBxmu40fJpLhARziJ_NrL_PW53vz0na4Elk7Q1K6vVbURUqCojCTd5MrdnefeSyUcsDqtnY_qekFxQ9GxuhDt7ju4zO-L2CP0Jkhrty5PVZgIJP2V5XmE1ZtpTfMA0QaaqsuIR0KzDwVBguk631tcFSRscNekH1UMkO_nPiAKGxbpKztIwxOv0jtVLDNFKGBVOMZE8cqNqpLMYglwTQ&token_type="
		"bearer&expires_in=900\\x12\\x1A\n\ttimestamp\\x12\r1606900484340\\x12H\n\\x0Ftransition_type\\x125PAGE_TRANSITION_LINK,PAGE_TRANSITION_CLIENT_REDIRECT,\\x9A\\x01\\xE8\\x12\n\\x17browser.page_transition\\x12\\xCC\\x11\n\\x08url_from\\x12\\xBF\\x11172.20.101.48/#state=b02ca27912e4a915910bb9ed1f057aecbdncVo9VW&session_state=75f8d79c-e114-4689-93a5-e78e5dd329cb&id_token="
		"eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJFUng4czVncHN2QUdmbks0b2hpWmxnM3hjVnRXU2JTLURUNmRZcFhYLWxRIn0.eyJqdGkiOiJhYTRhYmQ2NS0zZWYxLTQxYzAtYTcwZi0yNDgxZmJkNTVlMjEiLCJleHAiOjE2MDY5MDEzODQsIm5iZiI6MCwiaWF0IjoxNjA2OTAwNDg0LCJpc3MiOiJodHRwOi8vaWRtLXdlYnNzby5pcGEtY2lrLmxvY2FsOjgwODAvcmVhbG1zL3Rlc3QiLCJhdWQiOiJydWlwdGVzdCIsInN1YiI6IjY0ZjI3N2FkLTA5MjAtNDg2Yi05ZTM5LTU4ZDc5MTFiZTk1ZCIsInR5cCI6IklEIiwiYXpwIjoicnVpcHRlc3QiLCJub25jZSI6IjQ5ODBmNDBkZmYwN2RmZDkwOTFhNThmYzRlZWJjNzM0YTFCME40TnNpIiwiYXV0aF"
		"90aW1lIjoxNjA2OTAwNDY1LCJzZXNzaW9uX3N0YXRlIjoiNzVmOGQ3OWMtZTExNC00Njg5LTkzYTUtZTc4ZTVkZDMyOWNiIiwiYXRfaGFzaCI6Im1yekxiTHkwbGJJTjZkcEQxVUlzb0EiLCJhY3IiOiIwIiwic19oYXNoIjoiQ2UzcEE0U2owRFdUNHladThJS2h2dyIsInVzZXJuYW1lIjoibC5uLmR1cm92In0.TF3Q2IY9xPSHOMwufeYsWmNWCTzKq1wFnndK9TCfiEbxeUTiGwCX5HbdntFrUv7_98Npa97MqJbb-ypSvhDNLOwyed_HIxAH128Q6wxF7LPvW43CxG8wKPhky1LVgwrjRyxVk_dgOlo6FcDPHAh0ymKlV5favpGGm-2aCZ8zAc4s0_coO40vC9WIMRB1D6IfOYgrXpyrVS1OQEN50CFEvAUZsHtPwsg2vQamZrvHsvRV-WbX9FmLfCwZWciACRjxEqsO5PhnHE5v"
		"IXgPgkD7UifR0vDmMk7nBdD9hlYb7y3DLeHovFs6Ct5Cl_qpeUZYvieZCjhWSbftkaCLFUCmFA&access_token="
		"eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJFUng4czVncHN2QUdmbks0b2hpWmxnM3hjVnRXU2JTLURUNmRZcFhYLWxRIn0.eyJqdGkiOiI5MzY4MGRkYi04YmYxLTQ3MTMtOTUwYy00MTRmOWU4YTlhYzAiLCJleHAiOjE2MDY5MDEzODQsIm5iZiI6MCwiaWF0IjoxNjA2OTAwNDg0LCJpc3MiOiJodHRwOi8vaWRtLXdlYnNzby5pcGEtY2lrLmxvY2FsOjgwODAvcmVhbG1zL3Rlc3QiLCJzdWIiOiI2NGYyNzdhZC0wOTIwLTQ4NmItOWUzOS01OGQ3OTExYmU5NWQiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJydWlwdGVzdCIsIm5vbmNlIjoiNDk4MGY0MGRmZjA3ZGZkOTA5MWE1OGZjNGVlYmM3MzRhMUIwTjROc2kiLCJhdXRoX3RpbWUiOjE2MDY5MD"
		"A0NjUsInNlc3Npb25fc3RhdGUiOiI3NWY4ZDc5Yy1lMTE0LTQ2ODktOTNhNS1lNzhlNWRkMzI5Y2IiLCJhY3IiOiIwIiwic2NvcGUiOiJvcGVuaWQiLCJ1c2VybmFtZSI6Imwubi5kdXJvdiJ9.VmiGZow0aqdi0yiyLCkvgNiOx2dmXil7bor9skX6jOVkgPlcpPfaNcT7Z-TrgQHjSXm-o56k0BPHupgd5AV4GNjDHtE8oCNqlunShhrB8enr4A1hjNvgGYEb-uRtUE4IOG9dBxmu40fJpLhARziJ_NrL_PW53vz0na4Elk7Q1K6vVbURUqCojCTd5MrdnefeSyUcsDqtnY_qekFxQ9GxuhDt7ju4zO-L2CP0Jkhrty5PVZgIJP2V5XmE1ZtpTfMA0QaaqsuIR0KzDwVBguk631tcFSRscNekH1UMkO_nPiAKGxbpKztIwxOv0jtVLDNFKGBVOMZE8cqNqpLMYglwTQ&token_type="
		"bearer&expires_in=900\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.48/\\x12\\x1A\n\ttimestamp\\x12\r1606900485070\\x12H\n\\x0Ftransition_type\\x125PAGE_TRANSITION_LINK,PAGE_TRANSITION_CLIENT_REDIRECT,\\x9A\\x01\\xB5\\x01\n\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.48/\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.48/\\x12\\x1A\n\ttimestamp\\x12\r1606900485197\\x12H\n\\x0Ftransition_type\\x125PAGE_TRANSITION_LINK,PAGE_TRANSITION_CLIENT_REDIRECT,\\x9A\\x01\\xB5\\x01\n"
		"\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.48/\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.48/\\x12\\x1A\n\ttimestamp\\x12\r1606900485333\\x12H\n\\x0Ftransition_type\\x125PAGE_TRANSITION_LINK,PAGE_TRANSITION_CLIENT_REDIRECT,\\x9A\\x01\\xC8\\x03\n\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.48/\\x12\\xAA\\x02\n\\x06url_to\\x12\\x9F\\x02idm-websso.ipa-cik.local:8080/realms/test/protocol/openid-connect/auth?client_id=ruiptest&redirect_uri="
		"http%3A%2F%2F172.20.101.48&response_type=id_token%20token&scope=openid%20email%20profile&nonce=bd4fe4d48fd74400782a06b5ef9567dc75Vz2oyHy&state=f8f61a390ba7be9a599ebdae5d60c2b4b8yqhDcTd\\x12\\x1A\n\ttimestamp\\x12\r1606900489178\\x12H\n\\x0Ftransition_type\\x125PAGE_TRANSITION_LINK,PAGE_TRANSITION_CLIENT_REDIRECT,\\x9A\\x01\\x9E\\x01\n\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.48/\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.48/\\x12\\x1A\n\ttimestamp\\x12\r"
		"1606915610202\\x121\n\\x0Ftransition_type\\x12\\x1EPAGE_TRANSITION_AUTO_TOPLEVEL,\\x9A\\x01\\x95\\x01\n\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.48/\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.48/\\x12\\x1A\n\ttimestamp\\x12\r1606915611194\\x12(\n\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\x9A\\x01\\xC8\\x03\n\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.48/\\x12\\xAA\\x02\n\\x06url_to\\x12\\x9F\\x02idm-websso.ipa-cik.local:8080/"
		"realms/test/protocol/openid-connect/auth?client_id=ruiptest&redirect_uri=http%3A%2F%2F172.20.101.48&response_type=id_token%20token&scope=openid%20email%20profile&nonce=b65959622faf755cbb3a50d9adc3176ca0FWrMaz0&state=df40d893f6f026d4ba8e3cbcf504543a1dFKv23yX\\x12\\x1A\n\ttimestamp\\x12\r1606915612522\\x12H\n\\x0Ftransition_type\\x125PAGE_TRANSITION_LINK,PAGE_TRANSITION_CLIENT_REDIRECT,\\x9A\\x01\\xE2\\x14\n\\x17browser.page_transition\\x12\\xAC\\x02\n"
		"\\x08url_from\\x12\\x9F\\x02idm-websso.ipa-cik.local:8080/realms/test/protocol/openid-connect/auth?client_id=ruiptest&redirect_uri=http%3A%2F%2F172.20.101.48&response_type=id_token%20token&scope=openid%20email%20profile&nonce=b65959622faf755cbb3a50d9adc3176ca0FWrMaz0&state=df40d893f6f026d4ba8e3cbcf504543a1dFKv23yX\\x12\\xCA\\x11\n\\x06url_to\\x12\\xBF\\x11172.20.101.48/#state=df40d893f6f026d4ba8e3cbcf504543a1dFKv23yX&session_state=eb1fab8f-0494-430b-95ad-74b946ee2d72&id_token="
		"eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJFUng4czVncHN2QUdmbks0b2hpWmxnM3hjVnRXU2JTLURUNmRZcFhYLWxRIn0.eyJqdGkiOiJmZDAwNTRhMS1iNjExLTQ1OTItYjVkYy1iMDJhNDRiODJiMWUiLCJleHAiOjE2MDY5MTY1MTUsIm5iZiI6MCwiaWF0IjoxNjA2OTE1NjE1LCJpc3MiOiJodHRwOi8vaWRtLXdlYnNzby5pcGEtY2lrLmxvY2FsOjgwODAvcmVhbG1zL3Rlc3QiLCJhdWQiOiJydWlwdGVzdCIsInN1YiI6IjY0ZjI3N2FkLTA5MjAtNDg2Yi05ZTM5LTU4ZDc5MTFiZTk1ZCIsInR5cCI6IklEIiwiYXpwIjoicnVpcHRlc3QiLCJub25jZSI6ImI2NTk1OTYyMmZhZjc1NWNiYjNhNTBkOWFkYzMxNzZjYTBGV3JNYXowIiwiYXV0aF"
		"90aW1lIjoxNjA2OTE1NjE1LCJzZXNzaW9uX3N0YXRlIjoiZWIxZmFiOGYtMDQ5NC00MzBiLTk1YWQtNzRiOTQ2ZWUyZDcyIiwiYXRfaGFzaCI6Ii1iVkV4NzVONWZXSzF3QlNvTDliZmciLCJhY3IiOiIxIiwic19oYXNoIjoiWll4XzdObmRtMnU1cGFXcDY1X1ZtUSIsInVzZXJuYW1lIjoibC5uLmR1cm92In0.LsVrT897j5pdXOf0rOM-aX4Ep8cWeo3sbEOh-iikbOYwXEF1fouMn1GYCBNTORSD08pzr6w7Xk5wo67PhU5y5Z42sEDfpVltsb7t9wF_Y5NHtYRBJSV-BcaHv-e00LL3rKYi9-27zdakrWbNr8rVAjTMSQBq1efyZ1nS3Uj2mFynIgIsisA13HWB_Hy2rowzRw2nf7Q8kQCT-zrB6DM7RRHGeIwN_nQQMW0EXWJLv10JU_0wc1OJEajDZhE-pHP_c5Cb8nQo0INn"
		"WvmQQPj3mqK4Ed8Cy6oOEe44Ny6lP-FqzFSNI_2Sl5lqcxUQ4KnxuyT_ccytasAG-9fl47kBvQ&access_token="
		"eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJFUng4czVncHN2QUdmbks0b2hpWmxnM3hjVnRXU2JTLURUNmRZcFhYLWxRIn0.eyJqdGkiOiJjZTk4YTkyYS1kNTJlLTRmYzMtOGZlMC00OTlhMzg5MTMxZWYiLCJleHAiOjE2MDY5MTY1MTUsIm5iZiI6MCwiaWF0IjoxNjA2OTE1NjE1LCJpc3MiOiJodHRwOi8vaWRtLXdlYnNzby5pcGEtY2lrLmxvY2FsOjgwODAvcmVhbG1zL3Rlc3QiLCJzdWIiOiI2NGYyNzdhZC0wOTIwLTQ4NmItOWUzOS01OGQ3OTExYmU5NWQiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJydWlwdGVzdCIsIm5vbmNlIjoiYjY1OTU5NjIyZmFmNzU1Y2JiM2E1MGQ5YWRjMzE3NmNhMEZXck1hejAiLCJhdXRoX3RpbWUiOjE2MDY5MT"
		"U2MTUsInNlc3Npb25fc3RhdGUiOiJlYjFmYWI4Zi0wNDk0LTQzMGItOTVhZC03NGI5NDZlZTJkNzIiLCJhY3IiOiIxIiwic2NvcGUiOiJvcGVuaWQiLCJ1c2VybmFtZSI6Imwubi5kdXJvdiJ9.ST2WVK_5H5Qyh-5UYby7CQZHcBRGKrU8YYSpyf2Amcaf-zfbKiAL75aD8aFj4Kmm7g0fPTSE7M8u55iCul4NgYNskJeDTwWk7Tzy_FtAiddAF2xAT4cXbZ3Q-xJif9Uc07ypTmNIo34KVXuAAZAFrrKoeh3W41MUHpUf5TGptFt71GRPCnoOcRlIFKnIMtwLExPc_2tCvw8_9leTkV2UjieK6UH5k81ShVQq1RQifzQqfwsqs0RwWnko6zJB8oksLun8E9tKJxtAmEWG-V4Nvq4Dlakx4881sKE4Frj0XJMSr3-xmQhjJNFvHp4uzkVH3qixeV92L2yEaVFeJ8UZbw&token_type="
		"bearer&expires_in=900\\x12\\x1A\n\ttimestamp\\x12\r1606915616439\\x12/\n\\x0Ftransition_type\\x12\\x1CPAGE_TRANSITION_FORM_SUBMIT,\\x9A\\x01\\xC8\\x12\n\\x17browser.page_transition\\x12\\xCC\\x11\n\\x08url_from\\x12\\xBF\\x11172.20.101.48/#state=df40d893f6f026d4ba8e3cbcf504543a1dFKv23yX&session_state=eb1fab8f-0494-430b-95ad-74b946ee2d72&id_token="
		"eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJFUng4czVncHN2QUdmbks0b2hpWmxnM3hjVnRXU2JTLURUNmRZcFhYLWxRIn0.eyJqdGkiOiJmZDAwNTRhMS1iNjExLTQ1OTItYjVkYy1iMDJhNDRiODJiMWUiLCJleHAiOjE2MDY5MTY1MTUsIm5iZiI6MCwiaWF0IjoxNjA2OTE1NjE1LCJpc3MiOiJodHRwOi8vaWRtLXdlYnNzby5pcGEtY2lrLmxvY2FsOjgwODAvcmVhbG1zL3Rlc3QiLCJhdWQiOiJydWlwdGVzdCIsInN1YiI6IjY0ZjI3N2FkLTA5MjAtNDg2Yi05ZTM5LTU4ZDc5MTFiZTk1ZCIsInR5cCI6IklEIiwiYXpwIjoicnVpcHRlc3QiLCJub25jZSI6ImI2NTk1OTYyMmZhZjc1NWNiYjNhNTBkOWFkYzMxNzZjYTBGV3JNYXowIiwiYXV0aF"
		"90aW1lIjoxNjA2OTE1NjE1LCJzZXNzaW9uX3N0YXRlIjoiZWIxZmFiOGYtMDQ5NC00MzBiLTk1YWQtNzRiOTQ2ZWUyZDcyIiwiYXRfaGFzaCI6Ii1iVkV4NzVONWZXSzF3QlNvTDliZmciLCJhY3IiOiIxIiwic19oYXNoIjoiWll4XzdObmRtMnU1cGFXcDY1X1ZtUSIsInVzZXJuYW1lIjoibC5uLmR1cm92In0.LsVrT897j5pdXOf0rOM-aX4Ep8cWeo3sbEOh-iikbOYwXEF1fouMn1GYCBNTORSD08pzr6w7Xk5wo67PhU5y5Z42sEDfpVltsb7t9wF_Y5NHtYRBJSV-BcaHv-e00LL3rKYi9-27zdakrWbNr8rVAjTMSQBq1efyZ1nS3Uj2mFynIgIsisA13HWB_Hy2rowzRw2nf7Q8kQCT-zrB6DM7RRHGeIwN_nQQMW0EXWJLv10JU_0wc1OJEajDZhE-pHP_c5Cb8nQo0INn"
		"WvmQQPj3mqK4Ed8Cy6oOEe44Ny6lP-FqzFSNI_2Sl5lqcxUQ4KnxuyT_ccytasAG-9fl47kBvQ&access_token="
		"eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJFUng4czVncHN2QUdmbks0b2hpWmxnM3hjVnRXU2JTLURUNmRZcFhYLWxRIn0.eyJqdGkiOiJjZTk4YTkyYS1kNTJlLTRmYzMtOGZlMC00OTlhMzg5MTMxZWYiLCJleHAiOjE2MDY5MTY1MTUsIm5iZiI6MCwiaWF0IjoxNjA2OTE1NjE1LCJpc3MiOiJodHRwOi8vaWRtLXdlYnNzby5pcGEtY2lrLmxvY2FsOjgwODAvcmVhbG1zL3Rlc3QiLCJzdWIiOiI2NGYyNzdhZC0wOTIwLTQ4NmItOWUzOS01OGQ3OTExYmU5NWQiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJydWlwdGVzdCIsIm5vbmNlIjoiYjY1OTU5NjIyZmFmNzU1Y2JiM2E1MGQ5YWRjMzE3NmNhMEZXck1hejAiLCJhdXRoX3RpbWUiOjE2MDY5MT"
		"U2MTUsInNlc3Npb25fc3RhdGUiOiJlYjFmYWI4Zi0wNDk0LTQzMGItOTVhZC03NGI5NDZlZTJkNzIiLCJhY3IiOiIxIiwic2NvcGUiOiJvcGVuaWQiLCJ1c2VybmFtZSI6Imwubi5kdXJvdiJ9.ST2WVK_5H5Qyh-5UYby7CQZHcBRGKrU8YYSpyf2Amcaf-zfbKiAL75aD8aFj4Kmm7g0fPTSE7M8u55iCul4NgYNskJeDTwWk7Tzy_FtAiddAF2xAT4cXbZ3Q-xJif9Uc07ypTmNIo34KVXuAAZAFrrKoeh3W41MUHpUf5TGptFt71GRPCnoOcRlIFKnIMtwLExPc_2tCvw8_9leTkV2UjieK6UH5k81ShVQq1RQifzQqfwsqs0RwWnko6zJB8oksLun8E9tKJxtAmEWG-V4Nvq4Dlakx4881sKE4Frj0XJMSr3-xmQhjJNFvHp4uzkVH3qixeV92L2yEaVFeJ8UZbw&token_type="
		"bearer&expires_in=900\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.48/\\x12\\x1A\n\ttimestamp\\x12\r1606915616678\\x12(\n\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\x9A\\x01\\x95\\x01\n\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.48/\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.48/\\x12\\x1A\n\ttimestamp\\x12\r1606915616801\\x12(\n\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\x9A\\x01\\x95\\x01\n\\x17browser.page_transition\\x12\\x1A\n"
		"\\x08url_from\\x12\\x0E172.20.101.48/\\x12\\x18\n\\x06url_to\\x12\\x0E172.20.101.48/\\x12\\x1A\n\ttimestamp\\x12\r1606915616968\\x12(\n\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\x9A\\x01\\xA1\\x01\n\\x17browser.page_transition\\x12\\x1A\n\\x08url_from\\x12\\x0E172.20.101.48/\\x12$\n\\x06url_to\\x12\\x1A172.20.101.48/elector-list\\x12\\x1A\n\ttimestamp\\x12\r1606915619591\\x12(\n\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\x9A\\x01\\xA6\\x01\n\\x17browser.page_transition\\x12&\n"
		"\\x08url_from\\x12\\x1A172.20.101.48/elector-list\\x12\\x1D\n\\x06url_to\\x12\\x13172.20.101.48/error\\x12\\x1A\n\ttimestamp\\x12\r1606915620097\\x12(\n\\x0Ftransition_type\\x12\\x15PAGE_TRANSITION_LINK,\\xA2\\x01\\x00", 
		LAST);

	web_revert_auto_header("X-Chrome-UMA-ReportingInfo");

	web_add_header("Origin", 
		"http://172.20.101.52");

	web_add_header("X-Auth-Token", 
		"f392d4a4-8298-48e7-8311-e7f4f96676cc");

	web_custom_request("search", 
		"URL=http://172.20.101.52/gas-cik-rbd/electors/search?size=10&page=1&properties=%5B%7B%22name%22:%22lastName%22,%22direction%22:%22ASC%22%7D%5D&statusFilter=ALL&isApproved=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.20.101.52/elector-list", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=/assets/icons/standard-sprite/svg/symbols.svg", "Referer=http://172.20.101.52/elector-list?statusFilter=ALL&isApproved=true&selectedTab=mainAttrs", ENDITEM, 
		"Url=/assets/icons/action-sprite/svg/symbols.svg", "Referer=http://172.20.101.52/elector-list?statusFilter=ALL&isApproved=true&selectedTab=mainAttrs", ENDITEM, 
		LAST);

	return 0;
}
OpenDataOnUIK()
{

	return 0;
}
